class MyStuff(object):

    def __init__(self):
        self.tangerine="And now a thosand years between"

    def apple(self):
        print("I AM CLASSY APPLES!")
