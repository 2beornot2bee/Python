#this is goes in mystuff.py
def apple():
    print("I'm an apple")

#this is just a variable

tangerine="Living reflection of a drem"
