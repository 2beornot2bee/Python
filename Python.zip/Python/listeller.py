l=[1,2,3,4]
print(l)
l.append(55)
print(l)
l.insert(2,111)
print(l)