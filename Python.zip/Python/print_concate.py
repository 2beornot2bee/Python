isim="Ahmet"
soyad="kadir"
tel=5464
state= "insert into tablo (ad,soyad,telefon) value ("+isim+","+soyad+","+str(tel)+");"
print(state)
input()
